Run `make` to build main.pdf
